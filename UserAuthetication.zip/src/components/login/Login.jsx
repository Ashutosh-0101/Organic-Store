import React from 'react'
import { useNavigate } from 'react-router-dom';
import { chnageLoginStatus } from '../../redux/slices/LoginSlice';
import { useDispatch, useSelector } from 'react-redux';

const Login = () => {
    const navigate = useNavigate();
    const {loginStatus,key}=useSelector((store)=>store.login)
    console.log(key);
    const dispatch=useDispatch();
  
    const handleLogin = async () => {
        
        try{
            const res= await fetch(" https://dummyjson.com/auth/login",{
                method:'post',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    username:'emilys',
                    password:'emilyspass',
                    expiresInMins:30,
                })
            })
            const loginUser=await res.json();
            localStorage.setItem("auth", JSON.stringify({ isAuth: loginUser.token }));
            dispatch(chnageLoginStatus());
            alert("User logedin!");

        }
        catch(error)
        {
            console.log("error",error);

        }
     
    };
  
    const handleLogout = () => {
      localStorage.removeItem("auth");
      dispatch(chnageLoginStatus());
      navigate("/");
    };
  
  return (
    <div>
     <button onClick={!loginStatus ?handleLogin:handleLogout}>{!loginStatus ? "Login" : "Logout"}</button>
    </div>
  )
}

export default Login;