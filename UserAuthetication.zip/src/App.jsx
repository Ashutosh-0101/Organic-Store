import { useState } from 'react'

import './styles/App.css'
import AppRoute from './routes/AppRoutes'

function App() {

  return (
    <>
     <AppRoute/>
     </>
  )
}

export default App
