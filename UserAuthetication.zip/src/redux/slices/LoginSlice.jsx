import { createSlice } from "@reduxjs/toolkit";



const loginSlice=createSlice({
    name:"login",
    initialState:{loginStatus:false,key:1111},
    reducers:{
        chnageLoginStatus:(state)=>{
               state.loginStatus= !state.loginStatus
        }
    }
})

export const {chnageLoginStatus}=loginSlice.actions;
export default loginSlice.reducer;