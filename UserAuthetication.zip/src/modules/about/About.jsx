import React from 'react'

const Login = () => {
  return (
    <div style={{height:"100vh", width:"100%", backgroundColor:"yellow"}}>About</div>
  )
}

export default Login