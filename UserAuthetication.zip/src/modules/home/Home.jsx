import React from 'react'

const Home = () => {
  return (
    <div style={{height:"100vh", width:"100%", backgroundColor:"yellow"}}>Home</div>
  )
}

export default Home